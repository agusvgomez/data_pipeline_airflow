from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class LoadDimensionOperator(BaseOperator):

    ui_color = '#80BD9E'

    @apply_defaults
    def __init__(self,
                 sql_query = "",
                 delete = True,
                 table = "",
                 *args, **kwargs):

        super(LoadDimensionOperator, self).__init__(*args, **kwargs)
        self.sql_query = sql_query
        self.delete = delete
        self.table = table

    def execute(self, context):
        self.log.info('Loading Dimension task')
        redshift_hook = PostgresHook("redshift")
        if self.delete:
            self.log.info(f"Running delete statement on table {self.table}")
            redshift_hook.run(f"DELETE FROM {self.table}")
        self.log.info(f"Running query to load data into Dimension Table {self.table}")
        redshift_hook.run(self.sql_query)
        self.log.info(f"Dimension Table {self.table} loaded.")
