from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class TableCreatorOperator(BaseOperator):

    @apply_defaults
    def __init__(self,
                 *args, **kwargs):

        super(TableCreatorOperator, self).__init__(*args, **kwargs)

    def execute(self, context):
        self.log.info('Creating tables task')
        redshift = PostgresHook("redshift")
        queries =  open('/home/workspace/airflow/create_tables.sql', 'r').read()
        redshift.run(queries)
        self.log.info("Tables created")
